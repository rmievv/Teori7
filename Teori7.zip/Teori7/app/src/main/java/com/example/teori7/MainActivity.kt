package com.example.teori7

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvError: TextView
    private lateinit var listView: ListView
    private lateinit var layoutLoading: LinearLayout
    private lateinit var layoutError: LinearLayout
    private lateinit var btnCobaLagi: Button
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvError = findViewById(R.id.tvError)
        listView = findViewById(R.id.listUser)
        layoutLoading = findViewById(R.id.layoutLoading)
        layoutError = findViewById(R.id.layoutError)
        btnCobaLagi = findViewById(R.id.btnCobaLagi)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        listView.adapter = adapter

        btnCobaLagi.setOnClickListener { muatUsers() }

        muatUsers()
    }

    private fun tampilkanLoading() {
        tvStatus.text = "Memuat data..."
        layoutLoading.visibility = View.VISIBLE
        layoutError.visibility = View.GONE
        listView.visibility = View.GONE
    }

    private fun tampilkanDaftar() {
        layoutLoading.visibility = View.GONE
        layoutError.visibility = View.GONE
        listView.visibility = View.VISIBLE
    }

    private fun tampilkanError(pesan: String) {
        tvStatus.text = "Gagal memuat data"
        tvError.text = pesan
        layoutLoading.visibility = View.GONE
        layoutError.visibility = View.VISIBLE
        listView.visibility = View.GONE
    }

    private fun muatUsers() {
        tampilkanLoading()

        lifecycleScope.launch {
            try {
                // Jeda 1,5 detik HANYA agar loading kelihatan saat belajar.
                // Hapus baris ini kalau sudah paham.
                delay(1500)

                val daftar = RetrofitClient.api.getUsers()

                adapter.clear()
                adapter.addAll(daftar.map { "${it.name} (@${it.username})" })
                tvStatus.text = "${daftar.size} pengguna dimuat"
                tampilkanDaftar()

            } catch (e: HttpException) {
                tampilkanError("Server error: HTTP ${e.code()}")
            } catch (e: IOException) {
                tampilkanError("Tidak ada koneksi internet")
            }
        }
    }
}